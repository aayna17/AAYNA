
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface DashboardPreviewProps {
  userData: any;
}

const DashboardPreview = ({ userData }: DashboardPreviewProps) => {
  // Sample data for charts
  const barChartData = [
    { name: 'Jan', value: 40 },
    { name: 'Feb', value: 30 },
    { name: 'Mar', value: 45 },
    { name: 'Apr', value: 60 },
    { name: 'May', value: 75 },
    { name: 'Jun', value: 55 },
  ];

  const lineChartData = [
    { name: '1', value: 10 },
    { name: '2', value: 25 },
    { name: '3', value: 15 },
    { name: '4', value: 35 },
    { name: '5', value: 20 },
    { name: '6', value: 40 },
    { name: '7', value: 30 },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Account Completion</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Profile completion</span>
              <span className="font-medium">75%</span>
            </div>
            <Progress value={75} className="h-2" />
            
            <div className="pt-4">
              <h4 className="text-sm font-medium mb-2">Next steps:</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center text-gray-600">
                  <div className="w-5 h-5 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center mr-2 text-xs">
                    1
                  </div>
                  Complete your profile
                </li>
                <li className="flex items-center text-gray-600">
                  <div className="w-5 h-5 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center mr-2 text-xs">
                    2
                  </div>
                  Invite team members
                </li>
                <li className="flex items-center text-gray-600">
                  <div className="w-5 h-5 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center mr-2 text-xs">
                    3
                  </div>
                  Set up integrations
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Monthly Performance</CardTitle>
        </CardHeader>
        <CardContent className="h-[200px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={barChartData}>
              <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis hide />
              <Tooltip 
                contentStyle={{ background: 'white', border: '1px solid #f0f0f0', borderRadius: '6px', fontSize: '12px' }}
                itemStyle={{ color: '#333' }}
              />
              <Bar dataKey="value" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Weekly Activity</CardTitle>
        </CardHeader>
        <CardContent className="h-[200px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={lineChartData}>
              <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis hide />
              <Tooltip 
                contentStyle={{ background: 'white', border: '1px solid #f0f0f0', borderRadius: '6px', fontSize: '12px' }}
                itemStyle={{ color: '#333' }}
              />
              <Line type="monotone" dataKey="value" stroke="#0ea5e9" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Quick Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-sm text-gray-500">Company</div>
              <div className="font-medium mt-1">{userData?.companyName || 'Acme Inc.'}</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-sm text-gray-500">Industry</div>
              <div className="font-medium mt-1 capitalize">{userData?.industry || 'Technology'}</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-sm text-gray-500">Size</div>
              <div className="font-medium mt-1">{userData?.companySize || '11-50'} employees</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-sm text-gray-500">Features</div>
              <div className="font-medium mt-1">{userData?.selectedFeatures?.length || 3} selected</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardPreview;
