
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowRight, CheckCircle } from 'lucide-react';

interface StepOneProps {
  onNext: (data: any) => void;
  defaultValues?: {
    firstName?: string;
    lastName?: string;
    email?: string;
  };
}

const StepOne = ({ onNext, defaultValues = {} }: StepOneProps) => {
  const [formData, setFormData] = useState({
    firstName: defaultValues.firstName || '',
    lastName: defaultValues.lastName || '',
    email: defaultValues.email || '',
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    
    // Clear error when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };
  
  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.firstName.trim()) {
      newErrors.firstName = 'First name is required';
    }
    
    if (!formData.lastName.trim()) {
      newErrors.lastName = 'Last name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email address is invalid';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validate()) {
      onNext(formData);
    }
  };

  const isValid = (field: string) => {
    return formData[field as keyof typeof formData].trim() !== '' && !errors[field];
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h2 className="text-xl font-semibold text-center mb-6">Tell us about yourself</h2>
      
      <div className="grid gap-6 md:grid-cols-2">
        <div className="form-group">
          <Label htmlFor="firstName" className="flex items-center justify-between">
            <span>First Name</span>
            {isValid('firstName') && <CheckCircle className="h-4 w-4 text-green-500" />}
          </Label>
          <Input
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleInputChange}
            className={errors.firstName ? 'border-red-500' : ''}
            placeholder="John"
          />
          {errors.firstName && (
            <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>
          )}
        </div>
        
        <div className="form-group">
          <Label htmlFor="lastName" className="flex items-center justify-between">
            <span>Last Name</span>
            {isValid('lastName') && <CheckCircle className="h-4 w-4 text-green-500" />}
          </Label>
          <Input
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleInputChange}
            className={errors.lastName ? 'border-red-500' : ''}
            placeholder="Doe"
          />
          {errors.lastName && (
            <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>
          )}
        </div>
      </div>
      
      <div className="form-group">
        <Label htmlFor="email" className="flex items-center justify-between">
          <span>Email Address</span>
          {isValid('email') && <CheckCircle className="h-4 w-4 text-green-500" />}
        </Label>
        <Input
          id="email"
          name="email"
          type="email"
          value={formData.email}
          onChange={handleInputChange}
          className={errors.email ? 'border-red-500' : ''}
          placeholder="john.doe@example.com"
        />
        {errors.email && (
          <p className="text-red-500 text-sm mt-1">{errors.email}</p>
        )}
      </div>
      
      <div className="flex justify-end pt-4">
        <Button type="submit" className="bg-brand-500 hover:bg-brand-600">
          <span>Continue</span>
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </form>
  );
};

export default StepOne;
