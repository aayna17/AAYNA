
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';

interface StepThreeProps {
  onNext: (data: any) => void;
  onPrevious: () => void;
  defaultValues?: {
    emailNotifications?: boolean;
    marketingEmails?: boolean;
    productUpdates?: boolean;
    dataSharing?: boolean;
    selectedFeatures?: string[];
  };
}

const StepThree = ({ onNext, onPrevious, defaultValues = {} }: StepThreeProps) => {
  const [formData, setFormData] = useState({
    emailNotifications: defaultValues.emailNotifications !== undefined ? defaultValues.emailNotifications : true,
    marketingEmails: defaultValues.marketingEmails !== undefined ? defaultValues.marketingEmails : false,
    productUpdates: defaultValues.productUpdates !== undefined ? defaultValues.productUpdates : true,
    dataSharing: defaultValues.dataSharing !== undefined ? defaultValues.dataSharing : false,
    selectedFeatures: defaultValues.selectedFeatures || [],
  });
  
  const features = [
    { id: "dashboards", label: "Interactive Dashboards" },
    { id: "reporting", label: "Advanced Reporting" },
    { id: "analytics", label: "Data Analytics" },
    { id: "integration", label: "Third-party Integrations" },
    { id: "automation", label: "Workflow Automation" }
  ];
  
  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData({
      ...formData,
      [name]: checked,
    });
  };
  
  const handleFeatureChange = (featureId: string, checked: boolean) => {
    setFormData({
      ...formData,
      selectedFeatures: checked 
        ? [...formData.selectedFeatures, featureId]
        : formData.selectedFeatures.filter(id => id !== featureId),
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext(formData);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h2 className="text-xl font-semibold text-center mb-6">Customize your experience</h2>
      
      <div className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-base font-medium text-gray-800">Notification Preferences</h3>
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="emailNotifications" className="font-medium">Email Notifications</Label>
              <p className="text-sm text-gray-500">Receive notifications about your account</p>
            </div>
            <Switch
              id="emailNotifications"
              checked={formData.emailNotifications}
              onCheckedChange={(checked) => handleSwitchChange('emailNotifications', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="marketingEmails" className="font-medium">Marketing Emails</Label>
              <p className="text-sm text-gray-500">Receive marketing and promotional emails</p>
            </div>
            <Switch
              id="marketingEmails"
              checked={formData.marketingEmails}
              onCheckedChange={(checked) => handleSwitchChange('marketingEmails', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="productUpdates" className="font-medium">Product Updates</Label>
              <p className="text-sm text-gray-500">Get notified about new features and updates</p>
            </div>
            <Switch
              id="productUpdates"
              checked={formData.productUpdates}
              onCheckedChange={(checked) => handleSwitchChange('productUpdates', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="dataSharing" className="font-medium">Data Sharing</Label>
              <p className="text-sm text-gray-500">Allow anonymous usage data sharing</p>
            </div>
            <Switch
              id="dataSharing"
              checked={formData.dataSharing}
              onCheckedChange={(checked) => handleSwitchChange('dataSharing', checked)}
            />
          </div>
        </div>
        
        <div className="pt-4">
          <h3 className="text-base font-medium text-gray-800 mb-3">Select Features</h3>
          <p className="text-sm text-gray-500 mb-4">Choose features you're interested in:</p>
          
          <div className="grid gap-3 md:grid-cols-2">
            {features.map((feature) => (
              <div 
                key={feature.id}
                className="flex items-center space-x-3 rounded-md border p-4 hover:bg-gray-50 transition-colors"
              >
                <Checkbox
                  id={feature.id}
                  checked={formData.selectedFeatures.includes(feature.id)}
                  onCheckedChange={(checked) => handleFeatureChange(feature.id, checked as boolean)}
                />
                <Label htmlFor={feature.id} className="cursor-pointer flex-grow">
                  {feature.label}
                </Label>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="flex justify-between pt-4">
        <Button type="button" variant="outline" onClick={onPrevious}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          <span>Back</span>
        </Button>
        <Button type="submit" className="bg-brand-500 hover:bg-brand-600">
          <span>Complete Setup</span>
          <Check className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </form>
  );
};

export default StepThree;
