
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, ArrowRight, CheckCircle, Building2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface StepTwoProps {
  onNext: (data: any) => void;
  onPrevious: () => void;
  defaultValues?: {
    companyName?: string;
    companySize?: string;
    industry?: string;
  };
}

const StepTwo = ({ onNext, onPrevious, defaultValues = {} }: StepTwoProps) => {
  const [formData, setFormData] = useState({
    companyName: defaultValues.companyName || '',
    companySize: defaultValues.companySize || '',
    industry: defaultValues.industry || '',
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };
  
  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value,
    });
    
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };
  
  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.companyName.trim()) {
      newErrors.companyName = 'Company name is required';
    }
    
    if (!formData.companySize) {
      newErrors.companySize = 'Company size is required';
    }
    
    if (!formData.industry) {
      newErrors.industry = 'Industry is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validate()) {
      onNext(formData);
    }
  };
  
  const isValid = (field: string) => {
    return formData[field as keyof typeof formData] !== '' && !errors[field];
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h2 className="text-xl font-semibold text-center mb-6">Tell us about your company</h2>
      
      <div className="form-group">
        <Label htmlFor="companyName" className="flex items-center justify-between">
          <span>Company Name</span>
          {isValid('companyName') && <CheckCircle className="h-4 w-4 text-green-500" />}
        </Label>
        <div className="relative">
          <Input
            id="companyName"
            name="companyName"
            value={formData.companyName}
            onChange={handleInputChange}
            className={`pl-10 ${errors.companyName ? 'border-red-500' : ''}`}
            placeholder="Acme Inc."
          />
          <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
        </div>
        {errors.companyName && (
          <p className="text-red-500 text-sm mt-1">{errors.companyName}</p>
        )}
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        <div className="form-group">
          <Label htmlFor="companySize" className="flex items-center justify-between">
            <span>Company Size</span>
            {isValid('companySize') && <CheckCircle className="h-4 w-4 text-green-500" />}
          </Label>
          <Select
            value={formData.companySize}
            onValueChange={(value) => handleSelectChange('companySize', value)}
          >
            <SelectTrigger id="companySize" className={errors.companySize ? 'border-red-500' : ''}>
              <SelectValue placeholder="Select company size" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1-10">1-10 employees</SelectItem>
              <SelectItem value="11-50">11-50 employees</SelectItem>
              <SelectItem value="51-200">51-200 employees</SelectItem>
              <SelectItem value="201-500">201-500 employees</SelectItem>
              <SelectItem value="501+">501+ employees</SelectItem>
            </SelectContent>
          </Select>
          {errors.companySize && (
            <p className="text-red-500 text-sm mt-1">{errors.companySize}</p>
          )}
        </div>
        
        <div className="form-group">
          <Label htmlFor="industry" className="flex items-center justify-between">
            <span>Industry</span>
            {isValid('industry') && <CheckCircle className="h-4 w-4 text-green-500" />}
          </Label>
          <Select
            value={formData.industry}
            onValueChange={(value) => handleSelectChange('industry', value)}
          >
            <SelectTrigger id="industry" className={errors.industry ? 'border-red-500' : ''}>
              <SelectValue placeholder="Select industry" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="technology">Technology</SelectItem>
              <SelectItem value="healthcare">Healthcare</SelectItem>
              <SelectItem value="finance">Finance</SelectItem>
              <SelectItem value="education">Education</SelectItem>
              <SelectItem value="retail">Retail</SelectItem>
              <SelectItem value="manufacturing">Manufacturing</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
          {errors.industry && (
            <p className="text-red-500 text-sm mt-1">{errors.industry}</p>
          )}
        </div>
      </div>
      
      <div className="flex justify-between pt-4">
        <Button type="button" variant="outline" onClick={onPrevious}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          <span>Back</span>
        </Button>
        <Button type="submit" className="bg-brand-500 hover:bg-brand-600">
          <span>Continue</span>
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </form>
  );
};

export default StepTwo;
