
import { ReactNode } from 'react';
import ProgressBar from './ProgressBar';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

interface OnboardingLayoutProps {
  children: ReactNode;
  currentStep: number;
  totalSteps: number;
  title: string;
  subtitle?: string;
}

const OnboardingLayout = ({
  children,
  currentStep,
  totalSteps,
  title,
  subtitle,
}: OnboardingLayoutProps) => {
  const stepLabels = [
    'Personal Info',
    'Company',
    'Preferences',
    'Complete'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-10 px-4">
      <div className="onboarding-container">
        <div className="text-center mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">{title}</h1>
          {subtitle && <p className="text-gray-500 mt-2">{subtitle}</p>}
        </div>
        
        <ProgressBar
          currentStep={currentStep}
          totalSteps={totalSteps}
          labels={stepLabels}
        />
        
        <Card className="onboarding-card animate-slide-up">
          <CardContent className="pt-6">
            {children}
          </CardContent>
        </Card>
        
        <div className="text-center mt-6 text-sm text-gray-500">
          <p>Need help? <a href="#" className="text-brand-600 hover:underline">Contact support</a></p>
        </div>
      </div>
    </div>
  );
};

export default OnboardingLayout;
