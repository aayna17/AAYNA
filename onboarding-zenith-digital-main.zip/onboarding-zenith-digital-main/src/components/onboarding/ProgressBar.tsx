
import { cn } from '@/lib/utils';

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
  labels?: string[];
}

const ProgressBar = ({ currentStep, totalSteps, labels }: ProgressBarProps) => {
  const progressPercentage = ((currentStep - 1) / (totalSteps - 1)) * 100;
  
  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-2">
        {Array.from({ length: totalSteps }).map((_, index) => {
          const stepNumber = index + 1;
          const isActive = stepNumber <= currentStep;
          const isCurrentStep = stepNumber === currentStep;
          
          return (
            <div key={index} className="flex flex-col items-center relative">
              {/* Step circle */}
              <div 
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-200",
                  isActive ? "bg-brand-500 text-white" : "bg-gray-200 text-gray-500",
                  isCurrentStep ? "ring-4 ring-brand-100" : ""
                )}
              >
                {stepNumber}
              </div>
              
              {/* Step label */}
              {labels && (
                <span className={cn(
                  "text-xs mt-2 absolute -bottom-6 whitespace-nowrap",
                  isActive ? "text-brand-700 font-medium" : "text-gray-500"
                )}>
                  {labels[index]}
                </span>
              )}
            </div>
          );
        })}
      </div>
      
      {/* Progress bar */}
      <div className="w-full bg-gray-200 h-2 rounded-full mt-6 relative">
        <div 
          className="h-full bg-brand-500 rounded-full transition-all duration-500 ease-out"
          style={{ width: `${progressPercentage}%` }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;
