
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

interface SuccessScreenProps {
  userData: {
    firstName?: string;
  };
}

const SuccessScreen = ({ userData }: SuccessScreenProps) => {
  return (
    <div className="text-center py-6">
      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-6">
        <CheckCircle className="h-8 w-8 text-green-600" />
      </div>
      
      <h2 className="text-2xl font-bold text-gray-900 mb-2">
        Setup Complete!
      </h2>
      
      <p className="text-gray-600 mb-8">
        {userData.firstName ? `Congratulations ${userData.firstName}!` : 'Congratulations!'} Your account is ready to use. We've prepared your dashboard with everything you need to get started.
      </p>
      
      <div className="flex flex-col space-y-4 items-center max-w-xs mx-auto">
        <Button asChild className="w-full bg-brand-500 hover:bg-brand-600">
          <Link to="/dashboard">Go to Dashboard</Link>
        </Button>
        
        <Button variant="outline" className="w-full">
          <Link to="/">Back to Home</Link>
        </Button>
      </div>
      
      <div className="mt-10 pt-8 border-t border-gray-100">
        <p className="text-sm text-gray-500">
          Need help getting started? Check out our <a href="#" className="text-brand-600 hover:underline">quick start guide</a>.
        </p>
      </div>
    </div>
  );
};

export default SuccessScreen;
