
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import OnboardingLayout from '@/components/onboarding/OnboardingLayout';
import StepOne from '@/components/onboarding/StepOne';
import StepTwo from '@/components/onboarding/StepTwo';
import StepThree from '@/components/onboarding/StepThree';
import SuccessScreen from '@/components/onboarding/SuccessScreen';

const Onboarding = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [userData, setUserData] = useState({
    // Step One
    firstName: '',
    lastName: '',
    email: '',
    
    // Step Two
    companyName: '',
    companySize: '',
    industry: '',
    
    // Step Three
    emailNotifications: true,
    marketingEmails: false,
    productUpdates: true,
    dataSharing: false,
    selectedFeatures: [] as string[],
  });
  
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const totalSteps = 4; // Including success screen
  
  const handleStepOneNext = (data: any) => {
    setUserData({ ...userData, ...data });
    setCurrentStep(2);
    toast({
      title: "Personal information saved",
      description: "Your personal details have been saved successfully.",
    });
  };
  
  const handleStepTwoNext = (data: any) => {
    setUserData({ ...userData, ...data });
    setCurrentStep(3);
    toast({
      title: "Company information saved",
      description: "Your company details have been saved successfully.",
    });
  };
  
  const handleStepThreeNext = (data: any) => {
    setUserData({ ...userData, ...data });
    setCurrentStep(4);
    
    // In a real app, this is where you would send data to your API
    console.log('Onboarding complete with data:', { ...userData, ...data });
    
    toast({
      title: "Setup complete!",
      description: "Your preferences have been saved.",
      variant: "default",
    });
    
    // Save data to localStorage for persistence between sessions
    localStorage.setItem('onboardingData', JSON.stringify({ ...userData, ...data }));
  };
  
  const getStepTitle = () => {
    switch (currentStep) {
      case 1:
        return "Welcome to Digital Onboarding";
      case 2:
        return "Company Information";
      case 3:
        return "Your Preferences";
      case 4:
        return "Setup Complete";
      default:
        return "Digital Onboarding";
    }
  };
  
  const getStepSubtitle = () => {
    switch (currentStep) {
      case 1:
        return "Let's get to know you better";
      case 2:
        return "Tell us about your organization";
      case 3:
        return "Customize your experience";
      case 4:
        return "Your account is ready to use";
      default:
        return "";
    }
  };
  
  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <StepOne onNext={handleStepOneNext} defaultValues={userData} />;
      case 2:
        return (
          <StepTwo 
            onNext={handleStepTwoNext} 
            onPrevious={() => setCurrentStep(1)}
            defaultValues={userData}
          />
        );
      case 3:
        return (
          <StepThree 
            onNext={handleStepThreeNext} 
            onPrevious={() => setCurrentStep(2)}
            defaultValues={userData}
          />
        );
      case 4:
        return <SuccessScreen userData={userData} />;
      default:
        return null;
    }
  };

  return (
    <OnboardingLayout 
      currentStep={currentStep} 
      totalSteps={totalSteps}
      title={getStepTitle()}
      subtitle={getStepSubtitle()}
    >
      <div className="onboarding-step">
        {renderStep()}
      </div>
    </OnboardingLayout>
  );
};

export default Onboarding;
