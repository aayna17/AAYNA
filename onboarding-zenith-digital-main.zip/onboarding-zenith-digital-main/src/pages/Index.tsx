
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, BarChart3, Smile, Zap, Shield } from 'lucide-react';

const Index = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-white to-blue-50">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Digital Onboarding Optimization
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Streamline your onboarding process, improve user engagement, and boost conversion rates with our powerful onboarding platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                className="bg-brand-500 hover:bg-brand-600 text-white rounded-lg px-8 py-6 text-lg"
              >
                <Link to="/onboarding">
                  Get Started
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                className="rounded-lg px-8 py-6 text-lg"
              >
                <Link to="/dashboard">View Demo Dashboard</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Optimize Your Digital Onboarding</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our platform helps you create seamless onboarding experiences that convert more users and reduce drop-off rates.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-brand-100 rounded-lg flex items-center justify-center mb-4">
                <CheckCircle className="h-6 w-6 text-brand-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Simple Setup</h3>
              <p className="text-gray-600">
                Get started quickly with our intuitive onboarding process and pre-built templates.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-brand-100 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="h-6 w-6 text-brand-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Advanced Analytics</h3>
              <p className="text-gray-600">
                Track user progress and identify bottlenecks with detailed analytics and reporting.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-brand-100 rounded-lg flex items-center justify-center mb-4">
                <Smile className="h-6 w-6 text-brand-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">User-Friendly</h3>
              <p className="text-gray-600">
                Create engaging onboarding experiences that users love, with minimal effort.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-brand-100 rounded-lg flex items-center justify-center mb-4">
                <Zap className="h-6 w-6 text-brand-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Boost Conversion</h3>
              <p className="text-gray-600">
                Increase activation rates and reduce drop-offs with optimized onboarding flows.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gray-50 py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="bg-brand-500 rounded-2xl p-8 md:p-12 text-center text-white max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-4">Ready to optimize your onboarding?</h2>
            <p className="text-xl mb-8 opacity-90">
              Join thousands of companies that have improved their conversion rates with our platform.
            </p>
            <Button
              asChild
              variant="secondary"
              className="bg-white text-brand-700 hover:bg-gray-100 rounded-lg px-8 py-6 text-lg"
            >
              <Link to="/onboarding">
                Start Your Free Trial
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <h3 className="text-xl font-bold text-gray-900">Digital Onboarding</h3>
              <p className="text-gray-600 mt-2">Optimize your user onboarding experience</p>
            </div>
            <div className="flex space-x-8">
              <a href="#" className="text-gray-600 hover:text-brand-500">About</a>
              <a href="#" className="text-gray-600 hover:text-brand-500">Features</a>
              <a href="#" className="text-gray-600 hover:text-brand-500">Pricing</a>
              <a href="#" className="text-gray-600 hover:text-brand-500">Contact</a>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-8 pt-8 text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} Digital Onboarding Optimization. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
