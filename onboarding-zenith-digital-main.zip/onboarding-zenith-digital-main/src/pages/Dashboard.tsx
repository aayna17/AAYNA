
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import DashboardPreview from '@/components/dashboard/DashboardPreview';
import { User, Settings, LogOut, Bell, Activity, FileText, Users, Home } from 'lucide-react';

const Dashboard = () => {
  const [userData, setUserData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // In a real app, you would fetch user data from an API
    // Here we're using localStorage for demonstration purposes
    const storedData = localStorage.getItem('onboardingData');
    
    if (storedData) {
      setUserData(JSON.parse(storedData));
    }
    
    setLoading(false);
  }, []);
  
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-16 h-16 border-t-4 border-b-4 border-brand-500 rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Dashboard Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700">
              <Settings className="h-5 w-5" />
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center">
                <User className="h-4 w-4" />
              </div>
              <span className="hidden md:inline text-sm font-medium">
                {userData?.firstName || 'User'} {userData?.lastName || ''}
              </span>
            </div>
          </div>
        </div>
      </header>
      
      <div className="flex min-h-[calc(100vh-65px)]">
        {/* Sidebar */}
        <aside className="hidden md:block w-64 bg-white border-r border-gray-200 p-4">
          <nav className="space-y-1">
            <Link to="/dashboard" className="flex items-center px-3 py-2 text-sm font-medium rounded-md bg-brand-50 text-brand-700">
              <Home className="h-4 w-4 mr-3" />
              Dashboard
            </Link>
            <Link to="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50">
              <Activity className="h-4 w-4 mr-3" />
              Analytics
            </Link>
            <Link to="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50">
              <FileText className="h-4 w-4 mr-3" />
              Reports
            </Link>
            <Link to="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50">
              <Users className="h-4 w-4 mr-3" />
              Team
            </Link>
            <Link to="#" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50">
              <Settings className="h-4 w-4 mr-3" />
              Settings
            </Link>
          </nav>
          
          <div className="mt-8 pt-4 border-t border-gray-200">
            <Link to="/" className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50">
              <LogOut className="h-4 w-4 mr-3" />
              Sign Out
            </Link>
          </div>
        </aside>
        
        {/* Main Content */}
        <main className="flex-1 p-6">
          <div className="max-w-5xl mx-auto">
            {!userData ? (
              <Card>
                <CardHeader>
                  <CardTitle>Welcome to Your Dashboard</CardTitle>
                  <CardDescription>
                    It looks like you haven't completed the onboarding process yet.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-500">
                    To get started, please complete the onboarding process to set up your account.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button asChild>
                    <Link to="/onboarding">Complete Onboarding</Link>
                  </Button>
                </CardFooter>
              </Card>
            ) : (
              <>
                <div className="mb-8">
                  <h2 className="text-xl font-bold text-gray-900 mb-1">Welcome back, {userData.firstName}!</h2>
                  <p className="text-gray-500">Here's what's happening with your account today.</p>
                </div>
                
                <DashboardPreview userData={userData} />
              </>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
